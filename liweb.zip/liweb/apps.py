from django.apps import AppConfig


class LiwebConfig(AppConfig):
    name = 'liweb'
